$uname = $(Read-Host "Input Username Please:")
$pwd =$(Read-Host "Input the password:" -AsSecureString)

Get-VMHostAuthentication | Set-VMHostAuthentication -Domain 'example.domainname.local/OU1/OU2/OU3/' -JoinDomain -Username $uname -Password $pwd -Confirm:$false